/**
 * Google Apps Script for Traffic Accident Management (Full Sync Mode)
 * Updated Features: Cloud Auth, Settings Sync
 * 
 * Instructions:
 * 1. Open your Google Sheet
 * 2. Extensions > Apps Script
 * 3. Paste this code
 * 4. Run 'doGet' once to grant permissions
 * 5. Deploy > New Deployment > Web app
 *    - Execute as: Me
 *    - Who has access: Anyone
 * 6. Copy the URL to your App's settings
 */

var SHEET_NAME = "Cases";
var SETTINGS_SHEET_NAME = "Settings";

function doGet(e) {
    return handleRequest(e);
}

function doPost(e) {
    return handleRequest(e);
}

function handleRequest(e) {
    var lock = LockService.getScriptLock();
    // Wait for up to 30 seconds for other processes to finish.
    lock.tryLock(30000);

    try {
        var action = e.parameter.action;

        // --- LOGIN ACTION ---
        if (action === 'login') {
            return handleLogin(e);
        }

        // --- GET DATA ---
        if (e.postData === undefined || action === 'get') {
            var cases = readCases();
            var settings = readSettings();
            
            return ContentService.createTextOutput(JSON.stringify({
                status: 'success',
                data: JSON.stringify({
                    cases: cases,
                    settings: settings // Return settings including users
                })
            })).setMimeType(ContentService.MimeType.JSON);
        }

        // --- SAVE DATA (POST) ---
        var payload = JSON.parse(e.postData.contents);
        var responseData = { status: 'success' };

        // 1. Save Cases
        if (payload.cases && Array.isArray(payload.cases)) {
            saveCases(payload.cases);
        }

        // 2. Save Settings
        if (payload.settings) {
            saveSettings(payload.settings);
        }

        // 3. Process Uploads (New Feature)
        if (payload.uploads && Array.isArray(payload.uploads) && payload.uploads.length > 0) {
            responseData.uploadedLinks = processUploads(payload.uploads);
        }

        return ContentService.createTextOutput(JSON.stringify(responseData))
            .setMimeType(ContentService.MimeType.JSON);

    } catch (err) {
        return ContentService.createTextOutput(JSON.stringify({
            status: 'error',
            message: err.toString()
        })).setMimeType(ContentService.MimeType.JSON);
    } finally {
        lock.releaseLock();
    }
}

// --- FILE UPLOAD LOGIC ---
function processUploads(uploads) {
    var links = {};
    var folder = getDriveFolder();
    
    uploads.forEach(function(file) {
        try {
            var decoded = Utilities.base64Decode(file.base64);
            var blob = Utilities.newBlob(decoded, file.mimeType, file.fileName);
            var driveFile = folder.createFile(blob);
            
            // Set Public View Permission
            driveFile.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
            
            // Return the View URL
            links[file.tempId] = driveFile.getUrl();
        } catch(e) {
            links[file.tempId] = null; // Mark failed
        }
    });
    return links;
}

function getDriveFolder() {
    var folderName = "TrafficCaseFiles";
    var folders = DriveApp.getFoldersByName(folderName);
    if (folders.hasNext()) return folders.next();
    return DriveApp.createFolder(folderName);
}

// --- LOGIN LOGIC ---
function handleLogin(e) {
    var u = e.parameter.u;
    var p = e.parameter.p;
    
    // Read users from Settings
    var settings = readSettings();
    var users = settings.users || [];

    // Fallback: Default Admin if NO users defined at all
    if (users.length === 0) {
        if (u === 'admin' && p === 'admin') {
             return ContentService.createTextOutput(JSON.stringify({ status:'success', msg:'Default Admin' })).setMimeType(ContentService.MimeType.JSON);
        } else {
             return ContentService.createTextOutput(JSON.stringify({ status:'error', message:'No users defined (Default: admin/admin)' })).setMimeType(ContentService.MimeType.JSON);
        }
    }

    // Verify
    var valid = users.some(function(user) {
        return user.u === u && user.p === p;
    });

    if (valid) {
        return ContentService.createTextOutput(JSON.stringify({ status: 'success' })).setMimeType(ContentService.MimeType.JSON);
    } else {
        return ContentService.createTextOutput(JSON.stringify({ status: 'error', message: 'Invalid credentials' })).setMimeType(ContentService.MimeType.JSON);
    }
}

// --- SHEET HELPERS ---
function getSheet(name) {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName(name);
    if (!sheet) {
        sheet = ss.insertSheet(name);
        if (name === SHEET_NAME) {
            sheet.appendRow(["ID", "Date", "Name", "Plate", "Status", "JSON", "LastUpdated"]);
            sheet.setFrozenRows(1);
        }
    }
    return sheet;
}

// --- CASES I/O ---
function readCases() {
    var sheet = getSheet(SHEET_NAME);
    var lastRow = sheet.getLastRow();
    if (lastRow < 2) return [];

    var range = sheet.getRange(2, 1, lastRow - 1, 7); // Read 7 cols
    var values = range.getValues();
    var cases = [];

    for (var i = 0; i < values.length; i++) {
        var jsonStr = values[i][5]; // Col F (Index 5)
        if (jsonStr && jsonStr.startsWith("{")) {
            try {
                cases.push(JSON.parse(jsonStr));
            } catch (e) {}
        }
    }
    return cases;
}

function saveCases(cases) {
    var sheet = getSheet(SHEET_NAME);
    // Clear Content (Keep Header)
    var lastRow = sheet.getLastRow();
    if (lastRow > 1) {
        sheet.getRange(2, 1, lastRow - 1, sheet.getLastColumn()).clearContent();
    }
    
    if (cases.length === 0) return;

    var rows = cases.map(function (c) {
        return [
            c.id,
            c.date,
            c.clientName || '',
            c.plate || '',
            c.status || 'Waiting',
            JSON.stringify(c),
            new Date().toISOString()
        ];
    });

    sheet.getRange(2, 1, rows.length, rows[0].length).setValues(rows);
}

// --- SETTINGS I/O ---
function readSettings() {
    var sheet = getSheet(SETTINGS_SHEET_NAME);
    // Assuming settings is just one big JSON cell at A1 (simple)
    // Or we can assume row 1 is simple value.
    // Let's rely on reading A1.
    var val = sheet.getRange(1, 1).getValue();
    if (val && typeof val === 'string' && val.startsWith('{')) {
        try { return JSON.parse(val); } catch(e) { return {}; }
    }
    return {};
}

function saveSettings(settings) {
    var sheet = getSheet(SETTINGS_SHEET_NAME);
    sheet.clear();
    // Save as one big JSON string in cell A1. Efficient enough for small config.
    sheet.getRange(1, 1).setValue(JSON.stringify(settings));
}
